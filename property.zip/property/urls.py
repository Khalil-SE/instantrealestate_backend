from django.urls import path
from .views.lofty_views import (connect_lofty,lofty_callback,fetch_properties)
from property.views.property_views import PropertyListCreateView, PropertyRetrieveUpdateDestroyView

urlpatterns = [
    path('connect/', connect_lofty, name='connect-lofty'),
    path('callback/', lofty_callback, name='lofty-callback'),
    path('fetch-properties/', fetch_properties, name='fetch-properties'),


    path('', PropertyListCreateView.as_view(), name='property-list-create'),
    path('<int:pk>/', PropertyRetrieveUpdateDestroyView.as_view(), name='property-detail'),
]
